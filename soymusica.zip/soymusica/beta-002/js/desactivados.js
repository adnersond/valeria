sel_Modo_Clave.disabled = 'true';
sel_Modo_Clave.classList.add('combo_desactivado');

/*btn_Desafio.disabled = 'true';
btn_Desafio.classList.remove('boton');
btn_Desafio.classList.add('boton_desactivado');*/